import mongoose from "mongoose";

export const  connectDB = async () =>{
    await mongoose.connect('mongodb+srv://shrutibahuguna:Shruti1234@cluster1.vsesx.mongodb.net/fooddelivery').then(()=>console.log("DB Connected"));
}

