import React from 'react'
import './Header.css'

const Header = () => {
    return (
        <div className='header'>
            <div className='header-contents'>
                <h2>"Order your favorite food and enjoy delicious flavors!"</h2>
                <p>"Enjoy a variety of tasty dishes made with care and the best ingredients. Our goal is to make every meal special and satisfy your hunger with delicious flavors."</p>
                <button>View Menu</button>
            </div>
        </div>
    )
}

export default Header
